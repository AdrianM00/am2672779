/* 
 * File:   main.cpp
 * Author: Adrian Montoya
 * Created on June 24, 2016,  12:54 PM
 * Purpose: Determining the Amount of Memory
 */

//system Libraries
#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constant

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    
    //Process the Data
    
    //Output the processed Data
    
    cout << "The size of a char is: " << sizeof(char) << endl;
    cout << "The size of an int is: " << sizeof(int) << endl;
    cout << "The size of a float is: " << sizeof(float) << endl;
    cout << "The size of a double is: " << sizeof(double) << endl << endl; 
    
    //For the sake of this problem the question asked to determine the following: 
    //char, int, float and double; A double had to be determined to solve this problem.
 
    //Exit Stage Right!
    
    return 0;
}