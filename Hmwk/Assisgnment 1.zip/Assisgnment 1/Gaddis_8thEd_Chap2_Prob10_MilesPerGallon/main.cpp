/* 
 * File:   main.cpp
 * Author: Adrian Montoya
 * Created on June 24, 2016, 1:04 PM
 * Purpose Template
 */

//system Libraries
#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constant

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    
    float Gallons = 15, //Gallons of gas consumed
          Miles = 375, //Miles Driven
          MPG = Miles/Gallons; //MPG = Miles Driven/Gallons of Gas consumed
    
    //Process the Data
    
    //Output the processed Data
    
    cout << "A car that holds " << Gallons << " gallons of gasoline and" << endl;
    cout << "travels " << Miles << " Miles" << endl;
    cout << "gets " << MPG << " MPG " << endl;

    //Exit Stage Right!
    
    return 0;
}