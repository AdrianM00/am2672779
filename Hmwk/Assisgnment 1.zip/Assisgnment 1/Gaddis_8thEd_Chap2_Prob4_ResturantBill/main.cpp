/* 
 * File:   main.cpp
 * Author: Adrian Montoya
 * Created on June 24, 2016, 12:23 PM
 * Purpose: Restaurant Bill
 */

//system Libraries
#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constant

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    
    float   Tax = 0.0675, TaxAmount, // 6.75% of the meal cost
            Tip = 0.20, TipAmount, //20% of the total after adding tax
            Charge = 88.67, TotalBill;
    
    //Process the Data
    
    TaxAmount = Tax * Charge;
    TipAmount = Tip * (Charge + TaxAmount);
    TotalBill = Charge + TaxAmount + TipAmount;
    
    //Output the processed Data
    
    cout << "Meal cost: $" << Charge << endl;
    cout << "Tax amount: $" << TaxAmount << endl;
    cout << "Tip amount: $" << TipAmount << endl;
    cout << "Total bill: $" << TotalBill << endl;
        
    //Exit Stage Right!
    
    return 0;
}