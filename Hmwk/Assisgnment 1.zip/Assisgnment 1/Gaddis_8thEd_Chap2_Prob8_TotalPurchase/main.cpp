/* 
 * File:   main.cpp
 * Author: Adrian Montoya
 * Created on June 24, 2016, 12:48 PM
 * Purpose Total Purchase
 */

//system Libraries
#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constant

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    
    float item1 = 15.95, //Price of Item 1
          item2 = 24.95, //Price of Item 2
          item3 = 6.95, //Price of Item 3
          item4 = 12.95, //Price of Item 4
          item5 = 3.95, //Price of Item 5
            Tax,
            Total,
            SubTotal;
    
    
    //Process the Data
    
    SubTotal = item1 + item2 + item3 + item4 + item5;
    Tax = 0.07 * SubTotal; //Assuming the Sales Tax is 7%
    Total = Tax + SubTotal;
    
    //Output the processed Data
    
    cout << "Price of item 1 = $" << item1 << endl;
    cout << "Price of item 2 = $" << item2 << endl;
    cout << "Price of item 3 = $" << item3 << endl;
    cout << "Price of item 4 = $" << item4 << endl;
    cout << "Price of item 5 = $" << item5 << endl << endl;
    cout << "Subtotal = $" << SubTotal << endl;
    cout << "Tax = $" << Tax << endl;
    cout << "Total = $" << Total << endl << endl;
    
    //Exit Stage Right!
    
    return 0;
}