/* 
 * File:   main.cpp
 * Author: Adrian Montoya
 * Created on June 24, 2016, 2:00AM
 * Purpose Sales Prediction
 */

//system Libraries
#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constant

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    float GeneratedPercent = 0.58, //Company generates 58 percent total sales
            Sales=8.6e6, //Company has 8.6 Million in Sales this year
              GeneratedAmount; //How much the East Coast Division will generate
    
    //Process the Data
    GeneratedAmount = GeneratedPercent * Sales;
    
    //Output the processed Data
    
    cout << "Generating " << (GeneratedPercent * 100) << "% of total sales, the East Coast division " << endl;
    cout << "Generates $" << GeneratedAmount << " in sales this year." << endl;
        
    //Exit Stage Right!
    
    return 0;
}