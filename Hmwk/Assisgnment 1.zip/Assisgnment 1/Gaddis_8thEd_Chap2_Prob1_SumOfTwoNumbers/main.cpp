/* 
 * File:   main.cpp
 * Author: Adrian Montoya
 * Created on June 23, 2016, 6:51 PM
 * Purpose Sum of Two Numbers
 */

//system Libraries
#include <iostream> //Input/Output Library
#include <iomanip>
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constant

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
   
    
    //Input Data
    
   int num1 = 50,
        num2 = 100,
        total;
            
    //Process the Data
    
    total = num1 + num2;

    //Output the processed Data
    
    cout<<num1<<" + "<<num2<<" = "<<total<<endl;
    
    //Exit Stage Right!
    
    return 0;
}