/* 
 * File:   main.cpp
 * Author: Adrian Montoya
 * Created on June 20, 2016, 6:51 PM
 * Purpose: Ocean Levels
 */

//system Libraries
#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constant

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    
    float   FiveYears, //How high the ocean level will rise in 5 years
            SevenYears, //How high the ocean level will rise in 7 years
            TenYears; // How high the ocean level will rise in 10 years
    
    //Process the Data
    
    FiveYears = 5 * 1.5;
    SevenYears = 7 * 1.5;
    TenYears = 10 * 1.5;
    
    //Output the processed Data
    
    cout << "In 5 years the ocean's level be higher by " << FiveYears << " millimeters." << endl;
    cout << "In 7 years the ocean's level be higher by " << SevenYears << " millimeters." << endl;
    cout << "In 10 years the ocean's level be higher by " << TenYears << " millimeters." << endl;
    
//Exit Stage Right!
    
    return 0;
}