/* 
 * File:   main.cpp
 * Author: Adrian Montoya
 * Created on June 20, 2016, 6:51 PM
 * Purpose:  First Program
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    
    //Process the Data
    
    //Output the processed Data
    std::cout<<"Hello World"<<std::endl;
    
    //Exit Stage Right!
    return 0;
}