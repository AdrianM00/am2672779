/* 
 * File:   main.cpp
 * Author: Adrian Montoya
 * Created on June 24, 2016, 1:24 PM
 * Purpose: Personal Information on a single cout statement
 */

//system Libraries
#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constant

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    
    //Process the Data
    
    //Output the processed Data
    
    cout << "Adrian Montoya \n33720 Daily Rd, Menifee, CA, 92584 \n(951)445-2488 \nGeoscience" << endl;
   
    //Exit Stage Right!
    
    return 0;
}