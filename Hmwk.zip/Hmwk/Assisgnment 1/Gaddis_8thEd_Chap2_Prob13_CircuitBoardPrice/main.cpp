/* 
 * File:   main.cpp
 * Author: Adrian Montoya
 * Created on June 24, 2016, 1:14 PM
 * Purpose Calculating the price of a circuit board
 */

//system Libraries
#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constant

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    
    float BasePrice = 14.95,
          SellPrice;
   
    //Process the Data
    
    SellPrice = BasePrice + (0.35 * BasePrice);
    
    //Output the processed Data
    
    cout << "The selling price of a circuit board is: $" << SellPrice << endl;
    
    //Exit Stage Right!
    
    return 0;
}